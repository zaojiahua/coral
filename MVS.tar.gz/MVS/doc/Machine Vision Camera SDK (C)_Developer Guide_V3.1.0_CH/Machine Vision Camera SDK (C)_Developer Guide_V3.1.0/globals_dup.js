var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "a", "globals_a.html", null ],
    [ "b", "globals_b.html", null ],
    [ "f", "globals_f.html", null ],
    [ "i", "globals_i.html", null ],
    [ "m", "globals_m.html", null ],
    [ "o", "globals_o.html", null ],
    [ "t", "globals_t.html", null ],
    [ "v", "globals_v.html", null ]
];