var group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE5_x8F_x8A_xE9_x94_x80_xE6_xAF_x81 =
[
    [ "MV_CC_EnumerateTls", "group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE5_x8F_x8A_xE9_x94_x80_xE6_xAF_x81.html#ga041a15775822d43cd17228e5adc2fd99", null ],
    [ "MV_CC_EnumDevices", "group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE5_x8F_x8A_xE9_x94_x80_xE6_xAF_x81.html#ga88741869e2b3c12e47025e53e6a7b58b", null ],
    [ "MV_CC_EnumDevicesEx", "group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE5_x8F_x8A_xE9_x94_x80_xE6_xAF_x81.html#ga823b2ea8cf02a20ea37ade76f5aadc44", null ],
    [ "MV_CC_IsDeviceAccessible", "group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE5_x8F_x8A_xE9_x94_x80_xE6_xAF_x81.html#ga3c3ffcbd330529ee076433ef36d226f5", null ],
    [ "MV_CC_SetSDKLogPath", "group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE5_x8F_x8A_xE9_x94_x80_xE6_xAF_x81.html#ga9c6780918bdbd0b71ee9600e4e500b48", null ],
    [ "MV_CC_CreateHandle", "group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE5_x8F_x8A_xE9_x94_x80_xE6_xAF_x81.html#gab0a5b929b0bec89c1b2a66c7b30493ed", null ],
    [ "MV_CC_CreateHandleWithoutLog", "group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE5_x8F_x8A_xE9_x94_x80_xE6_xAF_x81.html#ga34305f862d50d20266be9824fa05cd2d", null ],
    [ "MV_CC_DestroyHandle", "group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE5_x8F_x8A_xE9_x94_x80_xE6_xAF_x81.html#ga0f74372a22e8a19fa7e21dad45070428", null ],
    [ "MV_CC_OpenDevice", "group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE5_x8F_x8A_xE9_x94_x80_xE6_xAF_x81.html#ga308c9a9869be7a457d27aadd94ce57dd", null ],
    [ "MV_CC_CloseDevice", "group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE5_x8F_x8A_xE9_x94_x80_xE6_xAF_x81.html#ga33853bd328f46492102246ca8b645d57", null ],
    [ "MV_CC_GetDeviceInfo", "group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x88_x9D_xE5_xA7_x8B_xE5_x8C_x96_xE5_x8F_x8A_xE9_x94_x80_xE6_xAF_x81.html#gaa20b5286abff02858bb4802f907c111d", null ]
];