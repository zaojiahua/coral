var group___xE7_x9B_xB8_xE6_x9C_xBA_xE5_x8A_x9F_xE8_x83_xBD_xE8_xAE_xBE_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3 =
[
    [ "通用接口", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html", "group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3" ],
    [ "GigE接口函数", "group___gig_e_xE6_x8E_xA5_xE5_x8F_xA3_xE5_x87_xBD_xE6_x95_xB0.html", "group___gig_e_xE6_x8E_xA5_xE5_x8F_xA3_xE5_x87_xBD_xE6_x95_xB0" ]
];