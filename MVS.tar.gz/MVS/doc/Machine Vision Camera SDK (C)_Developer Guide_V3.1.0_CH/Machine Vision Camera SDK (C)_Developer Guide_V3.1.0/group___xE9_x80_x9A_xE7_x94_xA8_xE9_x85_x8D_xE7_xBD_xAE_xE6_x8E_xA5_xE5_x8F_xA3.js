var group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3 =
[
    [ "MV_CC_GetIntValue", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#ga4c7fc34b34bb73d58076f7973c8ac69f", null ],
    [ "MV_CC_GetIntValueEx", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#ga8f46931327cb6e4a78703a3e3f201cfe", null ],
    [ "MV_CC_SetIntValue", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#ga6323cf15f3319cb2b23646c1ca03c166", null ],
    [ "MV_CC_SetIntValueEx", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#ga9bf0ac21078791974fd4f5b8b2c6328b", null ],
    [ "MV_CC_GetEnumValue", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#ga5436ee37cbc6073ebff2bffc5df21cd8", null ],
    [ "MV_CC_SetEnumValue", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#ga15a8abe28a1c5a53e10d115c7def4089", null ],
    [ "MV_CC_SetEnumValueByString", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#ga920d6f7c5547a7099feb85c6e9e738ab", null ],
    [ "MV_CC_GetFloatValue", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#ga4aa367e4bc6ec6a2d6e694e1386efc9d", null ],
    [ "MV_CC_SetFloatValue", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#gad43ad99b3a3a0ec2e91f6ad1ad4e99ac", null ],
    [ "MV_CC_GetBoolValue", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#gae775f048b5c49e2583378ba842e0fb1e", null ],
    [ "MV_CC_SetBoolValue", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#gad725e29bc56fa0eb57dfefb4d8d6ea69", null ],
    [ "MV_CC_GetStringValue", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#ga4ae9c5a0b988ddb627b5045662e559e0", null ],
    [ "MV_CC_SetStringValue", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#ga3c816d281b3941584a8fa8ebf14feda1", null ],
    [ "MV_CC_SetCommandValue", "group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html#ga1b85d5a9950f315471f4041db36a5c14", null ]
];