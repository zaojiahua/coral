/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "工业相机SDK(C)指导文档", "index.html", [
    [ "声明", "_xE5_xA3_xB0_xE6_x98_x8E.html", null ],
    [ "工业相机SDK(C)开发指南", "index.html", null ],
    [ "声明", "_xE5_xA3_xB0_xE6_x98_x8E.html", null ],
    [ "更新记录", "_xE6_x9B_xB4_xE6_x96_xB0_xE8_xAE_xB0_xE5_xBD_x95.html", null ],
    [ "环境配置", "_xE7_x8E_xAF_xE5_xA2_x83_xE9_x85_x8D_xE7_xBD_xAE.html", null ],
    [ "编程导引", "_xE7_xBC_x96_xE7_xA8_x8B_xE5_xAF_xBC_xE5_xBC_x95.html", null ],
    [ "相机参数节点表", "_xE7_x9B_xB8_xE6_x9C_xBA_xE5_x8F_x82_xE6_x95_xB0_xE8_x8A_x82_xE7_x82_xB9_xE8_xA1_xA8.html", null ],
    [ "示例", "_xE7_xA4_xBA_xE4_xBE_x8B.html", [
      [ "ChunkData.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#获取Chunk信息", null ],
      [ "ConnectSpecCamera.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#通过ip地址连接相机", null ],
      [ "Display.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#图像显示", null ],
      [ "Events.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#获取相机事件", null ],
      [ "ForceIP.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#设置相机静态ip", null ],
      [ "Grab_ImageCallback.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#通过回调获取相机图像", null ],
      [ "GrabImage.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#获取相机图像", null ],
      [ "GrabImage_HighPerformance.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#高性能获取相机图像", null ],
      [ "GrabMultipleCamera.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#多相机取流", null ],
      [ "ImageProcess.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#图像处理1", null ],
      [ "MultiCast.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#设置组播模式", null ],
      [ "ParametrizeCamera_FileAccess.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#导入或导出文件到相机", null ],
      [ "ParametrizeCamera_LoadAndSave.cpp    ", "_xE7_xA4_xBA_xE4_xBE_x8B.html#导入或导出相机属性", null ],
      [ "ReconnectDemo.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#相机重连", null ],
      [ "SetIO.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#设置相机IO", null ],
      [ "SetParam.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#设置相机参数", null ],
      [ "Trigger_Image.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#触发模式获取相机图像", null ],
      [ "Trigger_ImageCallback.cpp", "_xE7_xA4_xBA_xE4_xBE_x8B.html#触发模式下通过回调获取相机图像", null ]
    ] ],
    [ "错误码", "_xE9_x94_x99_xE8_xAF_xAF_xE7_xA0_x81.html", null ],
    [ "常见问题", "_xE5_xB8_xB8_xE8_xA7_x81_xE9_x97_xAE_xE9_xA2_x98.html", null ],
    [ "模块", "modules.html", "modules" ],
    [ "结构体", "annotated.html", [
      [ "结构体", "annotated.html", "annotated_dup" ],
      [ "成员变量", "functions.html", [
        [ "全部", "functions.html", "functions_dup" ],
        [ "变量", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "示例", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"_chunk_data_8cpp-example.html",
"struct_m_v___a_c_t_i_o_n___c_m_d___i_n_f_o.html#abfb421e2ba71606daef2f4cb0a87053b",
"struct_m_v___x_m_l___f_e_a_t_u_r_e___category.html#a8af2da2b729573b318a5e38134b1e618"
];

var SYNCONMSG = '点击 关闭 面板同步';
var SYNCOFFMSG = '点击 开启 面板同步';