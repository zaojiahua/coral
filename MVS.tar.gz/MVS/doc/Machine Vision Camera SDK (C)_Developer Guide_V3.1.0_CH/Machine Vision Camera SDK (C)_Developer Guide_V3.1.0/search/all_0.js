var searchData=
[
  ['_5f_5fstdcall',['__stdcall',['../_mv_camera_control_8h.html#ad16f14718feefaa629b3b7601ac9fdeb',1,'MvCameraControl.h']]]
];
