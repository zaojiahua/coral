var searchData=
[
  ['通用接口',['通用接口',['../group___xE9_x80_x9A_xE7_x94_xA8_xE6_x8E_xA5_xE5_x8F_xA3.html',1,'']]],
  ['通用配置接口',['通用配置接口',['../group___xE9_x80_x9A_xE7_x94_xA8_xE9_x85_x8D_xE7_xBD_xAE_xE6_x8E_xA5_xE5_x8F_xA3.html',1,'']]]
];
