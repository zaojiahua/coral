var searchData=
[
  ['info_5fmax_5fbuffer_5fsize',['INFO_MAX_BUFFER_SIZE',['../_camera_params_8h.html#a1644338fbee9e4bec300066ba337d4a8',1,'CameraParams.h']]]
];
