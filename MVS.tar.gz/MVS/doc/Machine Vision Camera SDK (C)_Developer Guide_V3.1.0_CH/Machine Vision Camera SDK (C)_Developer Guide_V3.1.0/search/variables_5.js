var searchData=
[
  ['hwnd',['hWnd',['../struct_m_v___d_i_s_p_l_a_y___f_r_a_m_e___i_n_f_o.html#abd2971b0e54c0ec50c1ca36de8ed11ae',1,'MV_DISPLAY_FRAME_INFO']]]
];
