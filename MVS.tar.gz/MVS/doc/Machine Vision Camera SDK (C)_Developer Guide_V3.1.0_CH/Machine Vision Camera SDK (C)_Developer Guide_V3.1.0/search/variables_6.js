var searchData=
[
  ['idproduct',['idProduct',['../struct_m_v___u_s_b3___d_e_v_i_c_e___i_n_f_o.html#a338e2cab0b74501173fa4900ddbb3517',1,'MV_USB3_DEVICE_INFO']]],
  ['idvendor',['idVendor',['../struct_m_v___u_s_b3___d_e_v_i_c_e___i_n_f_o.html#a80ce888aa87b8e6e7fd14c2d40900919',1,'MV_USB3_DEVICE_INFO']]],
  ['imethodvalue',['iMethodValue',['../struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#ac4f94bc4e57829c1201aae23291a218d',1,'MV_SAVE_IMAGE_PARAM_EX']]]
];
