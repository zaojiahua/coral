var searchData=
[
  ['pbroadcastaddress',['pBroadcastAddress',['../struct_m_v___a_c_t_i_o_n___c_m_d___i_n_f_o.html#abfb421e2ba71606daef2f4cb0a87053b',1,'MV_ACTION_CMD_INFO']]],
  ['pbufaddr',['pBufAddr',['../struct_m_v___f_r_a_m_e___o_u_t.html#ad09dec12abbdf5f6b77c47105e7eaaa9',1,'MV_FRAME_OUT']]],
  ['pchunkdata',['pChunkData',['../struct_m_v___c_h_u_n_k___d_a_t_a___c_o_n_t_e_n_t.html#a647605d766e4a513ad9f00203c3428a1',1,'MV_CHUNK_DATA_CONTENT']]],
  ['pdata',['pData',['../struct_m_v___d_i_s_p_l_a_y___f_r_a_m_e___i_n_f_o.html#aaf2599b3eef445bee5a6bd50569435f7',1,'MV_DISPLAY_FRAME_INFO::pData()'],['../struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m.html#aaf2599b3eef445bee5a6bd50569435f7',1,'MV_SAVE_IMAGE_PARAM::pData()'],['../struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#aaf2599b3eef445bee5a6bd50569435f7',1,'MV_SAVE_IMAGE_PARAM_EX::pData()'],['../struct_m_v___c_c___i_n_p_u_t___f_r_a_m_e___i_n_f_o.html#aaf2599b3eef445bee5a6bd50569435f7',1,'MV_CC_INPUT_FRAME_INFO::pData()']]],
  ['pdevfilename',['pDevFileName',['../struct_m_v___c_c___f_i_l_e___a_c_c_e_s_s.html#abddd31e5c91892bbbd8e406ed6ef5e1b',1,'MV_CC_FILE_ACCESS']]],
  ['pdeviceinfo',['pDeviceInfo',['../struct_m_v___c_c___d_e_v_i_c_e___i_n_f_o___l_i_s_t.html#ac8a3f91cd4d9e7f09ff4abaac031dffc',1,'MV_CC_DEVICE_INFO_LIST']]],
  ['pdstbuffer',['pDstBuffer',['../struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m.html#a5e9f33d08e3321873d38b6cb60cd021b',1,'MV_CC_PIXEL_CONVERT_PARAM']]],
  ['peventdata',['pEventData',['../struct_m_v___e_v_e_n_t___o_u_t___i_n_f_o.html#a46bacad7de0049c46da8a84c68648c9e',1,'MV_EVENT_OUT_INFO']]],
  ['pimagebuffer',['pImageBuffer',['../struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m.html#ad31a20e4c310f622fa7618dfe185d546',1,'MV_SAVE_IMAGE_PARAM::pImageBuffer()'],['../struct_m_v___s_a_v_e___i_m_a_g_e___p_a_r_a_m___e_x.html#ad31a20e4c310f622fa7618dfe185d546',1,'MV_SAVE_IMAGE_PARAM_EX::pImageBuffer()']]],
  ['pinfo',['pInfo',['../struct_m_v___a_l_l___m_a_t_c_h___i_n_f_o.html#a88a333e52f7669b3e1122b1e9d2d4aa3',1,'MV_ALL_MATCH_INFO']]],
  ['presults',['pResults',['../struct_m_v___a_c_t_i_o_n___c_m_d___r_e_s_u_l_t___l_i_s_t.html#a1e8bf114a5cf144fa9033377df87da80',1,'MV_ACTION_CMD_RESULT_LIST']]],
  ['psrcdata',['pSrcData',['../struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m.html#a05701d86c4ae0bb4955dbb4bfbafebee',1,'MV_CC_PIXEL_CONVERT_PARAM']]],
  ['punparsedchunkcontent',['pUnparsedChunkContent',['../struct_m_v___f_r_a_m_e___o_u_t___i_n_f_o___e_x.html#a785bdbf6ee966848ebee2ab3f2ee33e2',1,'MV_FRAME_OUT_INFO_EX']]],
  ['puserfilename',['pUserFileName',['../struct_m_v___c_c___f_i_l_e___a_c_c_e_s_s.html#a98c927bd20826c7b054cbac8295ee46b',1,'MV_CC_FILE_ACCESS']]]
];
