var struct_m_v___a_c_t_i_o_n___c_m_d___i_n_f_o =
[
    [ "nDeviceKey", "struct_m_v___a_c_t_i_o_n___c_m_d___i_n_f_o.html#a255319ce64d997a2f9b8977d7fbf0e47", null ],
    [ "nGroupKey", "struct_m_v___a_c_t_i_o_n___c_m_d___i_n_f_o.html#a543b4eb1fc629ef540d770d1ac8e2bf6", null ],
    [ "nGroupMask", "struct_m_v___a_c_t_i_o_n___c_m_d___i_n_f_o.html#a15bb72603d617e7a9fefd8eda7828948", null ],
    [ "bActionTimeEnable", "struct_m_v___a_c_t_i_o_n___c_m_d___i_n_f_o.html#a05a9c911c26fb2210de4c2e5a3a9796a", null ],
    [ "nActionTime", "struct_m_v___a_c_t_i_o_n___c_m_d___i_n_f_o.html#a3a65c3921b8a5b364fa6819acdc7f740", null ],
    [ "pBroadcastAddress", "struct_m_v___a_c_t_i_o_n___c_m_d___i_n_f_o.html#abfb421e2ba71606daef2f4cb0a87053b", null ],
    [ "nTimeOut", "struct_m_v___a_c_t_i_o_n___c_m_d___i_n_f_o.html#acfce7dffcc71a3fa05d41c06aadae9c5", null ],
    [ "nReserved", "struct_m_v___a_c_t_i_o_n___c_m_d___i_n_f_o.html#a0cb5815a0bf085826c780576fa8135a8", null ]
];