var struct_m_v___a_c_t_i_o_n___c_m_d___r_e_s_u_l_t___l_i_s_t =
[
    [ "nNumResults", "struct_m_v___a_c_t_i_o_n___c_m_d___r_e_s_u_l_t___l_i_s_t.html#a2a37ccfa4e474e41d765d55393ab8f3c", null ],
    [ "pResults", "struct_m_v___a_c_t_i_o_n___c_m_d___r_e_s_u_l_t___l_i_s_t.html#a1e8bf114a5cf144fa9033377df87da80", null ]
];