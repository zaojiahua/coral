var struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m =
[
    [ "nWidth", "struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m.html#a523c75b72da2a3bb32b97032f86c4703", null ],
    [ "nHeight", "struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m.html#a33071a62b54a3c9a671a0fcbe4804f1a", null ],
    [ "enSrcPixelType", "struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m.html#a6af584b61c57a08ee93ed39be605ba6f", null ],
    [ "pSrcData", "struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m.html#a05701d86c4ae0bb4955dbb4bfbafebee", null ],
    [ "nSrcDataLen", "struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m.html#a788363fe94292a9095c3db98ca86e355", null ],
    [ "enDstPixelType", "struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m.html#ab3d423dfc2e4facdbb48671b55e2a419", null ],
    [ "pDstBuffer", "struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m.html#a5e9f33d08e3321873d38b6cb60cd021b", null ],
    [ "nDstLen", "struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m.html#adadbb8d9782b35f3f3503bda429c4aff", null ],
    [ "nDstBufferSize", "struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m.html#adbd4a5ebaab5cca214c0f7bacee71676", null ],
    [ "nRes", "struct_m_v___c_c___p_i_x_e_l___c_o_n_v_e_r_t___p_a_r_a_m.html#af23125522cb1f9becc61e1947e79b281", null ]
];