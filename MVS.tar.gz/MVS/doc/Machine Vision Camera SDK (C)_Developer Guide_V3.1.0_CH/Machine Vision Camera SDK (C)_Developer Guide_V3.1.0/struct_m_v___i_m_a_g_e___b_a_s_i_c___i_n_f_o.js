var struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o =
[
    [ "nWidthValue", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#af6a23e7ba47ea8a6cf1a2424c957c0b6", null ],
    [ "nWidthMin", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#a8b9ee15a37e1371e18e173052c3f576e", null ],
    [ "nWidthMax", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#accbef050d1a3817d4c8494202034c7dc", null ],
    [ "nWidthInc", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#a00721e1da1b3173025aebefa24314033", null ],
    [ "nHeightValue", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#a3f6fe7ae201f8583b4dc34724b649845", null ],
    [ "nHeightMin", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#a6006665ae78bb93397526516e582bda6", null ],
    [ "nHeightMax", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#a40591f3f4217fcf111c5ae0f8a6cafdc", null ],
    [ "nHeightInc", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#a9ec9f8d701e54f2fd55779986f34dfcf", null ],
    [ "fFrameRateValue", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#aedb90c2a30df6c9d60bee7c936b81b2f", null ],
    [ "fFrameRateMin", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#a11c9fccbccc47c705136e6887819a31e", null ],
    [ "fFrameRateMax", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#ad8dab6d6edc0144352c4399477c5df93", null ],
    [ "enPixelType", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#a7a9fa8b758e413f5b96fa795d4ac5d8f", null ],
    [ "nSupportedPixelFmtNum", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#afcd8c573f7f30f65ffe94160c4c18be6", null ],
    [ "enPixelList", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#a8985663dd8735e4ec414fd4a1b4e77bf", null ],
    [ "nReserved", "struct_m_v___i_m_a_g_e___b_a_s_i_c___i_n_f_o.html#a6ee3001d9cdc554c411058ef6690e6a1", null ]
];