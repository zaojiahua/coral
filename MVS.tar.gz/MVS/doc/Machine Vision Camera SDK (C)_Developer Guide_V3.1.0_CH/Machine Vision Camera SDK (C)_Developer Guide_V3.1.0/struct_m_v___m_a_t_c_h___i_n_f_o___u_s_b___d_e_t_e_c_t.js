var struct_m_v___m_a_t_c_h___i_n_f_o___u_s_b___d_e_t_e_c_t =
[
    [ "nReviceDataSize", "struct_m_v___m_a_t_c_h___i_n_f_o___u_s_b___d_e_t_e_c_t.html#ab23114d93b7c0a387bd352144993d826", null ],
    [ "nRevicedFrameCount", "struct_m_v___m_a_t_c_h___i_n_f_o___u_s_b___d_e_t_e_c_t.html#a9c514385677889f2f256277cefee23d4", null ],
    [ "nErrorFrameCount", "struct_m_v___m_a_t_c_h___i_n_f_o___u_s_b___d_e_t_e_c_t.html#a95f5f8aa40e8248f6042d29b5b6b783b", null ],
    [ "nReserved", "struct_m_v___m_a_t_c_h___i_n_f_o___u_s_b___d_e_t_e_c_t.html#a81cb0717f9db166f066323bfdf9f8dde", null ]
];