var struct_m_v___n_e_t_t_r_a_n_s___i_n_f_o =
[
    [ "nReviceDataSize", "struct_m_v___n_e_t_t_r_a_n_s___i_n_f_o.html#ab23114d93b7c0a387bd352144993d826", null ],
    [ "nThrowFrameCount", "struct_m_v___n_e_t_t_r_a_n_s___i_n_f_o.html#a857e65dea9baf94e58fcfb9d0d4601d4", null ],
    [ "nNetRecvFrameCount", "struct_m_v___n_e_t_t_r_a_n_s___i_n_f_o.html#a90f4e88cb476d40340d180a67e352c49", null ],
    [ "nRequestResendPacketCount", "struct_m_v___n_e_t_t_r_a_n_s___i_n_f_o.html#a6e0ca8fbfc13258886a557ae22fd4d5a", null ],
    [ "nResendPacketCount", "struct_m_v___n_e_t_t_r_a_n_s___i_n_f_o.html#af5a46bdf52e0bc7d2e18dec7d6e7c65e", null ]
];