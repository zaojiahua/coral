var struct_m_v___x_m_l___f_e_a_t_u_r_e___string =
[
    [ "strName", "struct_m_v___x_m_l___f_e_a_t_u_r_e___string.html#a0d451332a9fb43e71b8cf2cc1820fd1c", null ],
    [ "strDisplayName", "struct_m_v___x_m_l___f_e_a_t_u_r_e___string.html#ae283984b173a15b099e9050d3602b429", null ],
    [ "strDescription", "struct_m_v___x_m_l___f_e_a_t_u_r_e___string.html#a230d54e14487f9f3e4f8cd70f9af24b2", null ],
    [ "strToolTip", "struct_m_v___x_m_l___f_e_a_t_u_r_e___string.html#a1957c2cffab26b5adf8dc405b6d09b63", null ],
    [ "enVisivility", "struct_m_v___x_m_l___f_e_a_t_u_r_e___string.html#a8af2da2b729573b318a5e38134b1e618", null ],
    [ "enAccessMode", "struct_m_v___x_m_l___f_e_a_t_u_r_e___string.html#ab02ea81a56e73106f7d86c60c81241da", null ],
    [ "bIsLocked", "struct_m_v___x_m_l___f_e_a_t_u_r_e___string.html#ab0325b5d774ea5b09ddd094246dad383", null ],
    [ "strValue", "struct_m_v___x_m_l___f_e_a_t_u_r_e___string.html#a25baed73feed52636f523664af79adfa", null ],
    [ "nReserved", "struct_m_v___x_m_l___f_e_a_t_u_r_e___string.html#a36997a85b4eaded7b74d90ca41312fee", null ]
];