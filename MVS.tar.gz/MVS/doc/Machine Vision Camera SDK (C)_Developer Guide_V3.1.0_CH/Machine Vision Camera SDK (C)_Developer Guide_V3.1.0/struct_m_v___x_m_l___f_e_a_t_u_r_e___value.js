var struct_m_v___x_m_l___f_e_a_t_u_r_e___value =
[
    [ "enType", "struct_m_v___x_m_l___f_e_a_t_u_r_e___value.html#a290315a8d24c3886c30aaf8c6d03fed9", null ],
    [ "strDescription", "struct_m_v___x_m_l___f_e_a_t_u_r_e___value.html#a230d54e14487f9f3e4f8cd70f9af24b2", null ],
    [ "strDisplayName", "struct_m_v___x_m_l___f_e_a_t_u_r_e___value.html#ae283984b173a15b099e9050d3602b429", null ],
    [ "strName", "struct_m_v___x_m_l___f_e_a_t_u_r_e___value.html#a0d451332a9fb43e71b8cf2cc1820fd1c", null ],
    [ "strToolTip", "struct_m_v___x_m_l___f_e_a_t_u_r_e___value.html#a1957c2cffab26b5adf8dc405b6d09b63", null ],
    [ "nReserved", "struct_m_v___x_m_l___f_e_a_t_u_r_e___value.html#a36997a85b4eaded7b74d90ca41312fee", null ]
];