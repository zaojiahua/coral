var struct_m_v_c_c___f_l_o_a_t_v_a_l_u_e =
[
    [ "fCurValue", "struct_m_v_c_c___f_l_o_a_t_v_a_l_u_e.html#a11e278521f1696dee14451558c04673a", null ],
    [ "fMax", "struct_m_v_c_c___f_l_o_a_t_v_a_l_u_e.html#aa60d48dd68ba894a23d9d9c458e68c8c", null ],
    [ "fMin", "struct_m_v_c_c___f_l_o_a_t_v_a_l_u_e.html#a583e02634a486008d7f1a58d4752ce30", null ],
    [ "nReserved", "struct_m_v_c_c___f_l_o_a_t_v_a_l_u_e.html#a36997a85b4eaded7b74d90ca41312fee", null ]
];